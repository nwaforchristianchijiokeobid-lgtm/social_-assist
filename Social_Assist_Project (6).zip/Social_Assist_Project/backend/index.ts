import {router,json,error,ai} from '@appdeploy/sdk';
const system='You are Social Assist, a warm, perceptive creative companion. Speak like a thoughtful human coach, not a chatbot or corporate report. Be natural, kind, honest, specific and useful. Never invent facts or pretend you saw inaccessible work. If evidence is limited, say so naturally and ask for context. Give a short conversational response, grounded strengths, improvements and up to three doable next steps. Return valid JSON only.';
export const handler=router({
'GET /api/_healthcheck':[async()=>json({message:'Social Assist is ready'})],
'POST /api/review':[async({body})=>{try{
const i=(body||{}) as {url?:string;focus?:string;notes?:string;memory?:string[];uploads?:Array<{name?:string;dataUrl?:string;type?:string}>};
const url=(i.url||'').trim(),notes=(i.notes||'').trim(),focus=(i.focus||'Creative direction').trim();
if(!url&&!notes&&!(i.uploads&&i.uploads.length))return error('Tell me about your work, share a link, or attach an image.',400);
if(url&&!/^https?:\/\//i.test(url))return error('Please use a complete link starting with https:// or http://.',400);
let sourceText='',title='A few thoughts on your work',sourceStatus='';
if(url){try{const s=await ai.scrape({url});if(s.status>=200&&s.status<400&&s.text&&s.text.trim().length>20){sourceText=s.text.slice(0,12000);title=s.title||title;sourceStatus='I could read some text from the page. Some visuals and private analytics may not be available.';}else sourceStatus='I could not get readable content from that page, so I will not guess what it contains.';}catch{sourceStatus='That platform would not let me read the page directly. I will only use what you shared here.';}}
const uploads=(i.uploads||[]).slice(0,4).map(f=>({name:f.name||'image',type:f.type||'image',supplied:!!f.dataUrl}));
const prompt='Focus: '+focus+'. User says: '+notes+'. Link: '+url+'. Page title: '+title+'. Accessible page text: '+(sourceText||'(none accessible; do not make claims about page contents)')+'. Attachments: '+JSON.stringify(uploads)+'. Prior notes: '+JSON.stringify((i.memory||[]).slice(-8))+'. File names alone do not reveal image contents; do not claim visual inspection if unavailable. Return JSON with title, summary, score, strengths, improvements, actions, sourceStatus.';
const r=await ai.generate({system,prompt,temperature:.55,maxTokens:1200,thinkingMode:'FAST',schema:{type:'object',properties:{title:{type:'string'},summary:{type:'string'},score:{type:'integer'},strengths:{type:'array',items:{type:'string'}},improvements:{type:'array',items:{type:'string'}},actions:{type:'array',items:{type:'string'}},sourceStatus:{type:'string'}},required:['title','summary','score','strengths','improvements','actions','sourceStatus']}});
let d;try{d=JSON.parse(r.text)}catch{return error('I couldn’t shape that into useful feedback. Please try again.',502)}
d.score=Math.max(1,Math.min(100,Number(d.score)||70));d.sourceStatus=sourceStatus||(uploads.length?'This version cannot yet inspect image pixels directly; a short description will help.':'Feedback based on the context you shared.');return json(d);
}catch(e){console.error(e);return error('I hit a snag. Please try again in a moment.',502)}}]
});
