# Social Assist

A human-first creative companion for portfolio feedback, audience growth, creative direction and progress tracking.

## Run locally
Requires Node.js 20+.
```bash
npm install
npm run dev
```
The backend uses the AppDeploy SDK/runtime. For standalone hosting, replace that integration with a configured AI provider and backend.

## Logo
`public/social-assist-eye.svg` is the simple illustrated eye mark. It is wired as the browser favicon, PWA icon, in-app brand mark, and the sign-in dialog logo.

## Included
- React + TypeScript frontend
- Responsive dark UI with lime accents
- Conversational review endpoint
- Memory and review history stored in browser local storage
- PWA manifest and SVG eye icon
- Authentication configuration and test scenarios

## Known limitations
- Sign-in uses AppDeploy-supported methods; a standalone six-digit email/SMS OTP flow is not included.
- Memory and reviews are browser-local, not synchronized across devices.
- The frontend reads attached images and sends data URLs, but the current backend does not pass image pixels into a vision model; it must not be treated as image-understanding-ready until connected to one.
- Push notifications and PWA installation need end-to-end testing on the target host.

Live app: https://social-assist-4t7ckt.v2.appdeploy.ai/
